<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Produtos_model extends CI_Model {
	
	public function get_byid($id = null){

        if($id != null){

            $this->db->from('produtos');
            $this->db->where('id', $id);
            $this->db->order_by('id','desc');

            return  $this->db->get();

        }else{

            return FALSE;
        }

    }
    public function get_produtos(){

        return  $this->db->get('produtos');

    }
    public  function do_insert($dados=null, $redir=true){

        if($dados != null){

            $this->db->insert('produtos',$dados);
            set_msg('msgok', 'Produto inserido com sucesso', 'sucesso');

            if($redir){
                redirect('produtos/gerenciar');
            }
        }
    }
	
	public function updateProdutos($dados=null, $condicao=null, $redir=null){

        if($dados != null){

            $this->db->update('produtos',$dados,$condicao);

            set_msg('msgok', 'produtos atualizado com sucesso', 'sucesso');
            redirect("produtos/gerenciar");
            
            if($redir){
                  redirect("produtos/gerenciar");
            }
        }

    }

    public  function do_upload($campo){

        $config['upload_path'] ='./produtos/'.'./uploads/';
        $config['encrypt_name'] = TRUE;
        $config['max_size']   = '5000';
        if (!is_dir($config['upload_path'])) {
            mkdir($config['upload_path'], 0777, TRUE);
        }
		
        $config['allowed_types']='jpg|gif|png';
        
        $this->load->library('upload',$config);

        if($this->upload->do_upload($campo)){
            return  $this->upload->data();
        }else{
            return $this->upload->display_errors();
        }
    }   
    public function do_delete($id){
      
            $this->db->where('id',$id);
            $this->db->delete('produtos');

            return  $this->db->get('produtos');
             set_msg('msgok', 'produtos deletados com sucesso', 'sucesso');
             redirect("produtos/gerenciar");
       
    }

       
}


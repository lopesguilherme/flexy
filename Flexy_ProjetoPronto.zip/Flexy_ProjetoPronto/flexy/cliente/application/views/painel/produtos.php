<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

        switch ($tela):
case 'gerenciar':
            ?>
    
            <div class="page-header">
                <h1 class="page-title">Produtos</h1>
                <div class="page-header-actions">
                    <a href="<?php echo base_url('produtos/cadastrar') ?>" class="btn btn-sm btn-icon btn-primary btn-round">
                        <i class="icon md-plus" aria-hidden="true"></i> Cadastrar
                    </a>
                </div>
            </div>
    
            <div class="page-content container-fluid">
                <?php
                erros_validacao();
                get_msg('msgok');
                get_msg('msgerro');
                ?>
                <div class="row" id="itens">
                    <div class="col-lg-6">
                        
                        <div class="panel">
                      
                             
                           <?php
                           $query = $this->produtos->get_produtos()->result();    
                             if ($query){  
                                foreach($query as $produtos){  
                              $queryprodutos = $this->produtos->get_byid($produtos->id)->row();    
                              $diretorioimagem= "uploads";         
                            ?> 
                            <div class="page-content-table" style="">
                            <table class="table">                  
                            <thead>
                                 <tr>
                                     <th>Titulo:</th>
                                     <th>Descrição:</th>
                                      <th>Valor:</th>
                                     </tr>
                             </thead>
                             <tbody>
                             <tr>
                          
                                   <img src=" <?php echo  $diretorioimagem . "/" ."$produtos->imagem"; ?>" img class="img-responsive" style ="width:400px;">
                                     <th> <?php echo $produtos->titulo ?>   </th>                      
                                    <th><?php echo $produtos->descricao ?> </th>                          
                                    <th><?php echo $produtos->valor ?> </th>  
                                    <th> <a href="<?php echo base_url('produtos/excluir/'.$produtos->id) ?>"> Excluir</th> 
                                    <th><a href="<?php echo base_url('produtos/alterar/'.$produtos->id) ?>">  Alterar</th> 
                                    </tr>
                                    </table>                       
                                </div>
                            <?php 
                            }       
                            ?>                            
                                                         
                                               
                                <?php                           
                        } else {
                                ?>
                                <ul class="list-group list-group-bordered">
                                    <div class="col-sm-12 col-md-12" style="padding-left: 0px !important;">
                                    <div class="alert dark alert-icon alert-warning alert-dismissible" role="alert">
                                        <i class="icon md-alert-circle-o" aria-hidden="true"></i> Você não possui <strong>produtos</strong> cadastrados.
                                    </div>
                                    </div>
                                     
                                    <?php }
                                    ?>
                                </ul> 
                                <?php
                            
                            ?>
                        </div>
                    </div>
                </div>
            </div>
    
            <?php
            break;

case 'cadastrar':
            ?>
    
            <div class="page animsition vertical-align text-center" data-animsition-in="fade-in"
                 data-animsition-out="fade-out">
                <div class="page-content vertical-align-middle">
                    <?php
                    erros_validacao();
                    get_msg('msgok');
                    get_msg('msgerro');
                    ?>                   
                      
                           <?php echo form_open_multipart('produtos/cadastrar', array('id' => 'formValidation'))?>                               
                                <div id="cadastro" style="display: block" class="margin-top-15">
                            
                                        <div class="form-group floating">
                                            <label class="control-label">Titulo</label>
                                            <input autocomplete="off" type="text" class="form-control" name="titulo" maxlength="510" <?php echo set_value('titulo'); ?> />
                                        </div>
                                        <div class="form-group floating">
                                            <label class="control-label">Descrição</label>
                                            <textarea name="descricao"  maxlength="500" class="form-control"  <?php echo set_value('descricao'); ?>></textarea>
                         
                                        </div>                               
                                   
                                    <div class="form-group floating">
                                            <label class="control-label">Imagem</label>
                                            <input type="file" class="form-control" name="imagem"  <?php echo set_value('imagem'); ?> />
                                        </div>                                       
                                    <div class="form-group floating">
                                             <label class="control-label">Valor</label>
                                             <input type="number"  name="valor" id="valor" <?php echo set_value('valor');?> />
                                    </div>
                                    <button id="validateButton" type="submit" class="btn btn-success btn-block btn-lg margin-top-20">Cadastrar</button>
                                    <p>&nbsp;</p>
                              
                                </div>
                            </form>
                        </div>
                    </div>            
            <?php
            break;
            case 'alterar':
?>


  <div class="page animsition vertical-align text-center" data-animsition-in="fade-in"
                 data-animsition-out="fade-out">
                <div class="page-content vertical-align-middle">
                    <?php
                    erros_validacao();
                    get_msg('msgok');
                    get_msg('msgerro');
                    ?>                   
                      
                           <?php echo form_open_multipart('produtos/alterar', array('id' => 'formValidation'))?>                               
                                <div id="cadastro" style="display: block" class="margin-top-15">
                            
                                        <div class="form-group floating">
                                            <label class="control-label">Titulo</label>
                                            <input autocomplete="off" type="text" class="form-control" name="titulo" maxlength="510" <?php echo set_value('titulo'); ?> />
                                        </div>
                                        <div class="form-group floating">
                                            <label class="control-label">Descrição</label>
                                            <textarea name="descricao"  maxlength="500" class="form-control"  <?php echo set_value('descricao'); ?>></textarea>
                         
                                        </div>                               
                                   
                                    <div class="form-group floating">
                                            <label class="control-label">Imagem</label>
                                            <input type="file" class="form-control" name="imagem"  <?php echo set_value('imagem'); ?> />
                                        </div>                                       
                                    <div class="form-group floating">
                                             <label class="control-label">Valor</label>
                                             <input type="number"  name="valor" id="valor" <?php echo set_value('valor');?> />
                                    </div>
                                    <button id="validateButton" type="submit" class="btn btn-success btn-block btn-lg margin-top-20">Cadastrar</button>
                                    <p>&nbsp;</p>
                              
                                </div>
                            </form>
                        </div>
                    </div>      
<?php
            break;
        endswitch;


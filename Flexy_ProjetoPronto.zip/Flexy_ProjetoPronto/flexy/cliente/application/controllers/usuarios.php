<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Usuarios extends CI_Controller {


    public function __construct() {

        parent::__construct();
        $this->load->library('sistema');
        $this->load->library('form_validation');
        init_painel(); //função do funcao_helper usado para carregar algumas funções
    }
	
	public function emailCheck($str)
        //valida se o email já está cadastrado
    {
        if ($this->usuarios->get_byemail($str)->num_rows() > 0) 
        {
            $this->form_validation->set_message('emailCheck', '%s já cadastrado no sistema');
            return FALSE;
        }
        else
        {
            return TRUE;
        }
    }	
	//sair do sistema
    public function logoff(){
        esta_logado(); //verifica se usuario ta logado
        $this->session->unset_userdata(array('id'=> '','nome'=>'','email'=>'','usuarioLogado'=>FALSE));
        $this->session->sess_destroy();
        $this->session->sess_create();
        set_msg('msgok','Logoff efetuado com sucesso', 'sucesso');
        redirect('usuarios/login');
    }
    public function login(){
        //Faz login no sistema, traz o email e senha do formulário, passando as regras de validações     
        	$this->form_validation->set_rules('login', 'Email','trim|required|strtolower|max_length[255]|valid_email|');
       		$this->form_validation->set_rules('senha', 'SENHA', 'trim|required|min_length[4]');
        	if($this->form_validation->run()==TRUE){			
			$email = $this->input->post('login', TRUE);
            $senha = $this->input->post('senha', TRUE);
            $senha = sha1($senha.'bacf4d8219f0ff1102468d0086a7530e4ddad5b4');			
            if($this->usuarios->do_login($email,$senha)){
                
                $query = $this->usuarios->get_byemail($email)->row();
                $dados = array(
					'id'=> $query->id,
                    'nome'=>$query->nome,					
                    'email'=>$query->email,
                    'usuarioLogado'=>TRUE
                );
				$this->session->set_userdata($dados);
				redirect('produtos/gerenciar '); // Direcionar pagina aqui
				
            }else{
                $query = $this->usuarios->get_byemail($email)->row();
                if(empty($query)){
                    set_msg('msgerro','Usuário Inexistente','erro');
                }elseif($query->senha != $senha){
                    set_msg('msgerro','Senha Incorreta','erro');					
				}
				redirect('usuarios/login');
				 }				
	        }
        set_tema('titulo', 'Login');
        set_tema('conteudo', load_modulo('usuarios', 'login'));
        load_template();
    }
	public function cadastrar(){
		
		$this->form_validation->set_rules('nome', 'Nome','trim|required|min_length[4]|max_length[500]');
		$this->form_validation->set_rules('email', 'Email','trim|required|strtolower|max_length[255]|valid_email|callback_emailCheck');
		$this->form_validation->set_rules('senha', 'Senha','trim|required|min_length[4]|max_length[100]|matches[pswConf]|callback_pswCheck');
        $this->form_validation->set_rules('pswConf', 'Confirmar Senha', 'trim|required|min_length[4]|max_length[100]');
		$this->form_validation->set_message('matches','O Campo %s está diferente do campo %s ');
        $this->form_validation->set_message('required', 'O campo %s é obrigatório');
		
		if($this->form_validation->run()== TRUE){					
			
			$dados = elements(array('nome','email','senha'), $this->input->post());
            $senha = $this->input->post('senha', TRUE);
            $senha = sha1($senha.'bacf4d8219f0ff1102468d0086a7530e4ddad5b4');
			$dados['nome'] = $this->input->post('nome');
			$dados['email'] = $this->input->post('email');
			$dados['senha'] = $senha;
            $this->usuarios->do_insert($dados);
        }
        set_tema('titulo', 'Cadastrar');
        set_tema('conteudo', load_modulo('usuarios', 'cadastrar'));
        load_template();
		}
}

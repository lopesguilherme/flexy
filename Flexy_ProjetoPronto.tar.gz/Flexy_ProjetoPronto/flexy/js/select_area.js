$(function () {
    $("#areas_box_1_show").click(function () {
        $("#area_1").fadeIn(700);
        $("#area_2").hide();
        $("#areas_box_1_show").css('border-bottom', '3px solid #E0B00C');
        $("#areas_box_2_show").css('border-bottom', 'none');
    });
    $("#areas_box_2_show").click(function () {
        $("#area_2").fadeIn(700);
        $("#area_1").hide();
        $("#areas_box_2_show").css('border-bottom', '3px solid #E0B00C');
        $("#areas_box_1_show").css('border-bottom', 'none');
    });
});
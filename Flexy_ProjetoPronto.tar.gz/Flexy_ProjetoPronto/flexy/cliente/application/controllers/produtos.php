<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Produtos extends CI_Controller {

   
    public function __construct() {

        parent::__construct();
        $this->load->library('sistema');
        init_painel();
   
    }
	
	
    public function gerenciar(){
        esta_logado();
        set_tema('titulo', 'Gerenciar Meus Produtos');
        set_tema('conteudo', load_modulo('produtos', 'gerenciar'));
        set_tema('rodape','');
        load_template();

    }

	public function cadastrar(){
        esta_logado();
        $uploadFotoPerfil = $this->produtos->do_upload('imagem');
		$this->form_validation->set_rules('titulo', 'Titulo','trim|required|min_length[4]|max_length[500]');
		$this->form_validation->set_rules('descricao', 'Descricao','trim|required|min_length[8]|max_length[500]');
        $this->form_validation->set_rules('valor', 'Valor','required');
		
		if($this->form_validation->run()== true){					
			
			$dados = elements(array('titulo','descricao','imagem','valor'), $this->input->post());
           
			$dados['titulo'] = $this->input->post('titulo');
            $dados['descricao'] = $this->input->post('descricao');            
            $dados['imagem'] =  $uploadFotoPerfil['file_name'];
            $dados['valor'] = $this->input->post('valor');
            $this->produtos->do_insert($dados);
            
            if(is_array($uploadFotoPerfil) && $uploadFotoPerfil['file_name'] != '' ){
                $dados['imagem'] = $uploadFotoPerfil['file_name'];
    
    
            }else{
                $dados['imagem'] = $this->input->post('hdFotoPerfil');
            }
       
       
       
    }
        set_tema('titulo', 'Cadastrar');
        set_tema('conteudo', load_modulo('produtos', 'cadastrar'));
        load_template();
		}

 
    public function alterar(){
         esta_logado();
        $uploadFotoPerfil = $this->produtos->do_upload('imagem');
		$this->form_validation->set_rules('titulo', 'Titulo','trim|min_length[4]|max_length[500]');
		$this->form_validation->set_rules('descricao', 'Descricao','trim|min_length[8]|max_length[500]');
        $this->form_validation->set_rules('valor', 'Valor');
		if($this->form_validation->run()== true){
            
        
        $dados['titulo'] = $this->input->post('titulo');
        $dados['descricao'] = $this->input->post('descricao');
        $dados['valor'] = $this->input->post('valor');
        $dados['imagem'] =  $uploadFotoPerfil['file_name'];  
       
         $this->produtos->updateProdutos($dados);
         if(is_array($uploadFotoPerfil) && $uploadFotoPerfil['file_name'] != '' ){
            $dados['imagem'] = $uploadFotoPerfil['file_name'];


        }else{
            $dados['imagem'] = $this->input->post('hdFotoPerfil');
        }   
        
    }           
        set_tema('titulo', 'Alterar');
        set_tema('conteudo', load_modulo('produtos', 'alterar'));
        load_template(); 
    }
    public function excluir($id){
        esta_logado();

        if($this->produtos->do_delete($id)){	
           
            set_tema('titulo', 'Excluir');
            set_tema('conteudo', load_modulo('produtos', 'gerenciar'));
            load_template();   
        }
    }
}   
<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');


switch ($tela):
    case 'login':
        ?>

        <div class="page animsition vertical-align text-center" data-animsition-in="fade-in"
             data-animsition-out="fade-out">
            <div class="page-content vertical-align-middle">
                <?php
                //vem la da funçoes_helper colocar em todas as paginas que tiverem alerta de erro e sucesso 
                erros_validacao();
                get_msg('msgok');
                get_msg('msgerro');
                ?>
                <div class="panel">
                    <div class="panel-body" style="padding: 0 10px !important;">
                        <div class="brand">
                            <img class="brand-img-login" src="<?php echo base_url('../files/assets/images/logo-lg.png') ?>" alt="...">
                        </div>
                        <?php
                        echo form_open('usuarios/login', array('id' => 'formValidation'));
                        ?>
                        <div class="form-group floating">
                            <label class="control-label">Digite seu email</label>
                            <input required="" autocomplete="off" type="text" class="form-control" name="login" />
                        </div>
                        <div class="form-group floating">
                            <label class="control-label">Senha</label>
                            <input required="" autocomplete="off" type="password" class="form-control" name="senha" />
                        </div>
                        <button id="validateButton" type="submit" class="btn btn-primary btn-block btn-lg btn-submit">Entrar</button>
                        </form>
                        <p>Não possui uma conta? <br><a href="<?php echo base_url('usuarios/cadastrar') ?>">Cadastre-se gratuitamente</a></p>
                    </div>
                </div>
            </div>
        </div>

        <?php
        break;

    case 'cadastrar':
        ?>

        <div class="page animsition vertical-align text-center" data-animsition-in="fade-in"
             data-animsition-out="fade-out">
            <div class="page-content vertical-align-middle">
                <?php
                erros_validacao();
                get_msg('msgok');
                get_msg('msgerro');
                ?>

                <div class="panel margin-top-20">
                    <div class="panel-body" style="padding: 0 10px !important;">
                        
                    <div class="brand">
                            <img class="brand-img-login" src="<?php echo base_url('../files/assets/images/logo-lg.png') ?>" alt="...">
                        </div>
                       
                        <form method="post" action="<?php echo base_url('usuarios/cadastrar') ?>" id="formValidation">
                          <div id="select_pes" style="display: block" class="margin-top-15">
                               
                          <div id="select_pes_fisica">
                                    <div class="form-group floating">
                                        <label class="control-label">Nome</label>
                                        <input autocomplete="off" type="text" class="form-control" name="nome" maxlength="510" <?php echo set_value('nome'); ?> />
                                    </div>
                                <div class="form-group floating">
                                    <label class="control-label">E-mail</label>
                                    <input required="" autocomplete="off" type="email" class="form-control" name="email" maxlength="510" <?php echo set_value('email'); ?> />
                                </div>
                            
                                <div class="form-group floating">
                                    <label class="control-label">Senha</label>
                                    <input required="" autocomplete="off" type="password" class="form-control" name="senha" data-fv-notempty="true"
                                           data-fv-notempty-message="The content is required and cannot be empty"
                                           data-fv-identical="true" data-fv-identical-field="pswConf"
                                           data-fv-identical-message="The content and its confirm are not the same"
                                           />
                                </div>
                                <div class="form-group floating">
                                    <label class="control-label">Confirmar Senha</label>
                                    <input required="" autocomplete="off" type="password" class="form-control" name="pswConf" data-fv-notempty="true"
                                           data-fv-notempty-message="The confirm content is required and cannot be empty"
                                           data-fv-identical="true" data-fv-identical-field="senha"
                                           data-fv-identical-message="The content and its confirm are not the same"
                                           />
                                </div>
                                <button id="validateButton" type="submit" class="btn btn-success btn-block btn-lg margin-top-20">Continuar</button>
                                <p>&nbsp;</p>
                                <p>Já possui uma conta? <a href="<?php echo base_url('usuarios/login') ?>">Acesse agora</a></p>
                            </div>
                        </form>
                    </div>
                </div>
                <footer class="page-copyright page-copyright-inverse">
                </footer>
            </div>
        </div>

        <?php
        break;

    default:
        echo '<div class="alert alert-error">
							<button type="button" class="close" data-dismiss="alert">?</button>
							<strong>Opss!</strong> Desculpe, a tela solicitada não existe.
						</div>';
        break;
endswitch;

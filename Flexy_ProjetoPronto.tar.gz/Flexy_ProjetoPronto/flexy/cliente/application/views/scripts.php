<!-- Core  -->
<script src="<?php echo base_url('../files/global/vendor/jquery/jquery.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/bootstrap/bootstrap.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/animsition/animsition.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/asscroll/jquery-asScroll.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/mousewheel/jquery.mousewheel.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/asscrollable/jquery.asScrollable.all.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/ashoverscroll/jquery-asHoverScroll.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/waves/waves.js') ?>"></script>

<!-- Plugins -->
<script src="<?php echo base_url('../files/global/vendor/switchery/switchery.min.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/intro-js/intro.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/screenfull/screenfull.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/slidepanel/jquery-slidePanel.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/jquery-placeholder/jquery.placeholder.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/icheck/icheck.min.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/formvalidation/formValidation.min.js') ?>"></script>
<script src="<?php echo base_url('../files/global/vendor/formvalidation/framework/bootstrap.min.js') ?>"></script>

<!-- Scripts -->
<script src="<?php echo base_url('../files/global/js/core.js') ?>"></script>

<script src="<?php echo base_url('../files/assets/js/html2canvas.min.js') ?>"></script>
<script src="<?php echo base_url('../files/assets/js/canvas2image.js') ?>"></script>

<script src="<?php echo base_url('../files/assets/js/site.js') ?>"></script>
<script src="<?php echo base_url('../files/assets/js/jquery.mask.js') ?>"></script>
<script src="<?php echo base_url('../files/assets/js/custom.js') ?>"></script>
<script src="<?php echo base_url('../files/assets/js/sections/menu.js') ?>"></script>
<script src="<?php echo base_url('../files/assets/js/sections/menubar.js') ?>"></script>
<script src="<?php echo base_url('../files/assets/js/sections/gridmenu.js') ?>"></script>
<script src="<?php echo base_url('../files/assets/js/sections/sidebar.js') ?>"></script>
<script src="<?php echo base_url('../files/global/js/configs/config-colors.js') ?>"></script>
<script src="<?php echo base_url('../files/assets/js/configs/config-tour.js') ?>"></script>
<script src="<?php echo base_url('../files/global/js/components/asscrollable.js') ?>"></script>
<script src="<?php echo base_url('../files/global/js/components/animsition.js') ?>"></script>
<script src="<?php echo base_url('../files/global/js/components/slidepanel.js') ?>"></script>
<script src="<?php echo base_url('../files/global/js/components/switchery.js') ?>"></script>
<script src="<?php echo base_url('../files/global/js/components/tabs.js') ?>"></script>
<script src="<?php echo base_url('../files/global/js/components/jquery-placeholder.js') ?>"></script>
<script src="<?php echo base_url('../files/global/js/components/material.js') ?>"></script>
<script src="<?php echo base_url('../files/global/js/components/icheck.js') ?>"></script>
<script src="<?php echo base_url('../files/assets/examples/js/forms/validation.js') ?>"></script>
<script src="<?php echo base_url('../files/assets/examples/js/forms/validation-custom.js') ?>"></script>

<script src="<?php echo base_url('../files/global/js/plugins/responsive-tabs.min.js') ?>"></script>
<script src="<?php echo base_url('../files/global/js/plugins/closeable-tabs.min.js') ?>"></script>
<script src="<?php echo base_url('../files/global/js/components/tabs.min.js') ?>"></script>

<script>
    (function (document, window, $) {
        'use strict';
        var Site = window.Site;
        $(document).ready(function () {
            Site.run();
        });
    })(document, window, jQuery);
</script>
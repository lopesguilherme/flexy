<?php
if ($this->uri->segment(1) == 'usuarios') {
    $class_perfil = 'active';
} else {
    $class_perfil = '';
}
?>
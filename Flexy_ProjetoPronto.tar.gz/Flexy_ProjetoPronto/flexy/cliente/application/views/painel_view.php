<!DOCTYPE html>
<html class="no-js css-menubar" lang="pt - BR">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <meta name="description" content="bootstrap admin template">
        <meta name="author" content="">

        <title><?php if (isset($titulo)) { ?>{titulo} | <?php } ?> {titulo_padrao}</title>

        <!-- Stylesheets -->
        <link rel="stylesheet" href="<?php echo base_url('../files/global/css/bootstrap.css') ?>">
        <link rel="stylesheet" href="<?php echo base_url('../files/global/css/bootstrap-extend.css') ?>">
        <link rel="stylesheet" href="<?php echo base_url('../files/assets/css/site.css') ?>">
        <?php
        if ($this->uri->segment(1) == 'usuarios') {
            if ($this->uri->segment(2) == 'login' || $this->uri->segment(2) == 'cadastrar') {
                ?>
                <link rel="stylesheet" href="<?php echo base_url('../files/assets/examples/css/pages/login-v3.css') ?>"> 
                <?php
            }
        }
        ?>
         <!-- Fonts -->
        <link rel="stylesheet" href="<?php echo base_url('../files/global/fonts/material-design/material-design.css') ?>">
        <link rel="stylesheet" href="<?php echo base_url('../files/global/fonts/brand-icons/brand-icons.css') ?>">
        <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:300,400,500,300italic'>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    </head> 

    <?php
    if ($this->uri->segment(1) == 'usuarios') {
        if ($this->uri->segment(2) == 'login' || $this->uri->segment(2) == 'cadastrar') {
            ?>
            <body class="page-login-v3 layout-full"> 
                <?php
            } if ($this->uri->segment(2) == 'redefinirSenha' || $this->uri->segment(2) == 'confirmarCadastro') {
                ?>
            <body class="page-forgot-password layout-full">
                <?php
            }
        } else {
            ?>
        <body class="dashboard">
        <?php } ?>
        
 <?php
        if (esta_logado(FALSE)) {
            ?> 
            <nav class="site-navbar navbar navbar-inverse navbar-fixed-top navbar-mega" role="navigation">
                <div class="navbar-header">                 
                    <a href="<?php echo base_url('usuarios/logoff') ?>" class="navbar-toggle">
                        <i class="icon fa fa-sign-out" aria-hidden="true"></i>
                    </a>                   
                    <div class="navbar-brand navbar-brand-center" data-toggle="gridmenu">
                     <a href="/flexy/cliente/produtos/gerenciar">   <img class="navbar-brand-logo" src="<?php echo base_url('../files/assets/images/logo-sm.png') ?>" title="Logo"> </a>
                    </div>
                </div>
                <div class="navbar-container container-fluid">
                    <div class="collapse navbar-collapse navbar-collapse-toolbar" id="site-navbar-collapse">
                        <ul class="nav navbar-toolbar navbar-right navbar-toolbar-right">
                            <li class="dropdown">
                                <a class="navbar-avatar dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false"
                                   data-animation="scale-up" role="button">
                                    <span class="avatar avatar-online">
                                        <img src="<?php echo base_url('../files/global/portraits/Darth-Vader.jpg') ?>" alt="...">
                                        <i></i>
                                    </span>
                                </a>
                                <ul class="dropdown-menu" role="menu">
                                    
                                    <li class="divider" role="presentation"></li>
                                    <li role="presentation">
                                        <a href="<?php echo base_url('usuarios/logoff') ?>" role="menuitem"><i class="icon fa fa-sign-out" aria-hidden="true"></i> Sair</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>

                </div>
            </nav>

            <?php
            include 'menu.php';
            ?>


            <div class="page animsition">
                {conteudo}
            </div>

        <?php } else { ?>
            {conteudo}
        <?php } ?>   

    </body>

    <?php
    include 'scripts.php';
    ?>

</html>
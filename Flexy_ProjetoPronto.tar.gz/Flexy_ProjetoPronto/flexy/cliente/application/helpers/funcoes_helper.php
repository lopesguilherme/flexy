<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

//carrega modulo do sistema devolvendo a tela solicitada

function load_modulo($modulo = NULL, $tela = NULL, $diretorio = 'painel') {

    $CI = & get_instance();

    if ($modulo != NULL) {

        return $CI->load->view("$diretorio/$modulo", array('tela' => $tela), TRUE);
    } else {


        return FALSE;
    }
}

//seta valores  ao array tema da classe sistema

function set_tema($prop, $valor, $replace = TRUE) {

    $CI = & get_instance();
    $CI->load->library('sistema');


    if ($replace) {
        $CI->sistema->tema[$prop] = $valor;
    } else {

        if (!isset($CI->sistema->tema[$prop])) {

            $CI->sistema->tema[$prop] = '';
        }

        $CI->sistema->tema[$prop].=$valor;
    }
}

function get_tema() {
    $CI = & get_instance();
    $CI->load->library('sistema');

    return $CI->sistema->tema;
}

function init_painel() {

    $CI = & get_instance();

    $CI->load->library(array('sistema', 'session', 'form_validation'));
    $CI->load->helper(array('form', 'url', 'array', 'text'));
    $CI->load->model('usuarios_model', 'usuarios');
    $CI->load->model('produtos_model', 'produtos');
    

    //Só para quando não achar o titulo da pagina lá da controller 
    set_tema('titulo_padrao', 'TITULO PADRAO TESTE');
    set_tema('rodape', '<p>&copy ' . date('Y') . ' | </p>');
    set_tema('template', 'painel_view');


    set_tema('headerinc', load_css(array(
        'bootstraps')), FALSE);


    set_tema('footerinc', load_js(array(
        'charts')), FALSE);
}

function load_template() {

    $CI = & get_instance();
    $CI->load->library('sistema');

    $CI->parser->parse($CI->sistema->tema['template'], get_tema());
}

//carregar arquivos css de uma pasta

function load_css($arquivo = NULL, $pasta = 'css', $media = 'all') {

    if ($arquivo != NULL) {
        $CI = & get_instance();
        $CI->load->helper('url');
        $retorno = '';

        if (is_array($arquivo)) {

            foreach ($arquivo as $css) {

                $retorno .='<link rel="stylesheet" type="text/css" href="' . base_url("$pasta/$css.css") . '" media="' . $media . '" />';
            }
        } else {


            $retorno = '<link rel="stylesheet" type="text/css" href="' . base_url("$pasta/$arquivo.css") . '" media="' . $media . '" />';
        }
    }

    return $retorno;
}

//carrega arquivos js de uma pasta ou servidor remoto


function load_js($arquivo = NULL, $pasta = 'js', $remoto = FALSE) {


    if ($arquivo != NULL) {
        $CI = & get_instance();
        $CI->load->helper('url');
        $retorno = '';

        if (is_array($arquivo)) {

            foreach ($arquivo as $js) {

                if ($remoto) {

                    $retorno.='<script  type="text/javascript" src="' . $js . '"></script>';
                } else {

                    $retorno.='<script  type="text/javascript" src="' . base_url("$pasta/$js.js") . '"></script>';
                }
            }
        } else {


            if ($remoto) {

                $retorno.='<script  type="text/javascript" src="' . $arquivo . '"></script>';
            } else {

                $retorno.='<script  type="text/javascript" src="' . base_url("$pasta/$arquivo.js") . '"></script>';
            }
        }
    }

    return $retorno;
}

//mostra erros formularios

function erros_validacao() {

    if (validation_errors()) {

        echo '<div class="panel-alert">
                <div class="alert dark alert-alt alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <strong><i class="icon wb-close margin-right-10" aria-hidden="true"></i> ' . validation_errors('<span>', '</span><br>') . '</strong>
                </div>
            </div>';
    }
}

//verifica se usuario está logado no sistema

function esta_logado($redir = TRUE) {

    $CI = & get_instance();

    $CI->load->library('session');

    $user_status = $CI->session->userdata('usuarioLogado');

    if (!isset($user_status) || $user_status != TRUE) {


        if ($redir) {
            set_msg('errologin', 'Acesso Restrito, faça login antes de prosseguir', 'erro');

            redirect('usuarios/login');
        } else {

            return FALSE;
        }
    } else {

        return TRUE;
    }
}

//definie mensagem para ser exibida na proxima tela carregada
function set_msg($id = "msgerro", $msg = NULL, $tipo = "erro") {

    $CI = & get_instance();
    $CI->load->library('session');

    switch ($tipo) {
        case 'erro':
            $CI->session->set_flashdata($id, '<div class="panel-alert">
                                                <div class="alert dark alert-alt alert-danger alert-dismissible" role="alert">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                    <strong><i class="icon wb-close margin-right-10" aria-hidden="true"></i> ' . $msg . '.</strong>
                                                </div>
                                            </div>');
            break;
        case 'sucesso':
            $CI->session->set_flashdata($id, '<div class="panel-alert">
                                                <div class="alert dark alert-alt alert-success alert-dismissible" role="alert">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                    <strong><i class="icon wb-check margin-right-10" aria-hidden="true"></i> ' . $msg . '.</strong>
                                                </div>
                                            </div>');
            break;

        default:
            $CI->session->set_flashdata($id, '<div class="panel-alert">
                                                <div class="alert dark alert-alt alert-primary alert-dismissible" role="alert">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                    <strong><i class="icon wb-info margin-right-10" aria-hidden="true"></i> ' . $msg . '.</strong>
                                                </div>
                                            </div>');
            break;
    }
}

function set_msg_site($id = "msgerro", $msg = NULL, $tipo = "erro") {

    $CI = & get_instance();
    $CI->load->library('session');

    switch ($tipo) {
        case 'erro':
            $CI->session->set_flashdata($id, '<div class="panel-alert">
                                                <div class="alert dark alert-alt alert-danger alert-dismissible" role="alert">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                    <strong><i class="icon wb-close margin-right-10" aria-hidden="true"></i> ' . $msg . '.</strong>
                                                </div>
                                            </div>');
            break;
        case 'sucesso':
            $CI->session->set_flashdata($id, '<div class="panel-alert">
                                                <div class="alert dark alert-alt alert-success alert-dismissible" role="alert">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                    <strong><i class="icon wb-check margin-right-10" aria-hidden="true"></i> ' . $msg . '.</strong>
                                                </div>
                                            </div>');
            break;

        default:
            $CI->session->set_flashdata($id, '<div class="panel-alert">
                                                <div class="alert dark alert-alt alert-primary alert-dismissible" role="alert">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                    <strong><i class="icon wb-info margin-right-10" aria-hidden="true"></i> ' . $msg . '.</strong>
                                                </div>
                                            </div>');
            break;
    }
}

function mask($val, $mask){
$maskared = '';
$k = 0;
    for($i = 0; $i<=strlen($mask)-1; $i++){
        if($mask[$i] == '#'){
            if(isset($val[$k]))
                $maskared .= $val[$k++];
        }else{
            if(isset($mask[$i]))
                $maskared .= $mask[$i];
        }
    }
 return $maskared;
}

//verifica se existe mensagem para swer exibida

function get_msg($id, $printar = TRUE) {

    $CI = & get_instance();
    $CI->load->library('session');

    if ($CI->session->flashdata($id)) {


        if ($printar) {

            echo $CI->session->flashdata($id);
            return TRUE;
        } else {

            return $CI->session->flashdata($id);
        }
    }
    return FALSE;
}

function get_msg_site($id, $printar = TRUE) {

    $CI = & get_instance();
    $CI->load->library('session');

    if ($CI->session->flashdata($id)) {


        if ($printar) {

            echo $CI->session->flashdata($id);
            return TRUE;
        } else {

            return $CI->session->flashdata($id);
        }
    }
    return FALSE;
}

function formata_preco($valor) {
    $negativo = false;
    $preco = "";
    $valor = intval(trim($valor));
    if ($valor < 0) {
        $negativo = true;
        $valor = abs($valor);
    }
    $valor = strrev($valor);
    while (strlen($valor) < 3) {
        $valor .= "0";
    }
    for ($i = 0; $i < strlen($valor); $i++) {
        if ($i == 2) {
            $preco .= ",";
        }
        if (($i <> 2) AND ( ($i + 1) % 3 == 0)) {
            $preco .= ".";
        }
        $preco .= substr($valor, $i, 1);
    }
    $preco = strrev($preco);
    return ($negativo ? "-" : "") . $preco;
}

function soNumero($str) {
    return preg_replace("/[^0-9]/", "", $str);
}

function sanitizeString($string) {

    // matriz de entrada
    $what = array('ä', 'ã', 'à', 'á', 'â', 'ê', 'ë', 'è', 'é', 'ï', 'ì', 'í', 'ö', 'õ', 'ò', 'ó', 'ô', 'ü', 'ù', 'ú', 'û', 'À', 'Á', 'Ã', 'É', 'Ê', 'Í', 'Ó', 'Õ', 'Ú', 'ñ', 'Ñ', 'ç', 'Ç', '-', '(', ')', ',', ';', ':', '|', '!', '"', '#', '$', '%', '&', '/', '=', '?', '~', '^', '>', '<', 'ª', 'º');

    // matriz de saída
    $by = array('a', 'a', 'a', 'a', 'a', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'A', 'A', 'A', 'E', 'E', 'I', 'O', 'O', 'U', 'n', 'n', 'c', 'C', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_');

    // devolver a string
    return str_replace($what, $by, $string);
}

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Usuarios_model extends CI_Model {
	
	public function get_byid($id = null){

        if($id != null){

            $this->db->from('usuarios');
            $this->db->where('id', $id);
            $this->db->limit(1);

            return  $this->db->get();

        }else{

            return FALSE;
        }

    }
	
	public function do_login($email = null, $senha=null) {

        if($email != null && $senha != null){

            $this->db->where('email',$email);
            $this->db->where('senha',$senha);
     
            
            $query = $this->db->get('usuarios');

            if($query->num_rows ==1){
                return TRUE;

            }else {
                return FALSE;

            }

        }else{

            return  FALSE;

        }

    }
	


    public function get_byemail($email = null){

        if($email != null){

            $this->db->from('usuarios');
            $this->db->where('email', $email);
            $this->db->limit(1);

            return  $this->db->get();

        }else{

            return FALSE;
        }

    }
	
	public  function do_insert($dados=null, $redir=true){

        if($dados != null){

            $this->db->insert('usuarios',$dados);
            set_msg('msgok', 'Cadastro efetuado com sucesso.', 'sucesso');

            if($redir){
                redirect('usuarios/login/');
            }
        }
    }
	
}

/* End of file usuarios_model.php */
/* Location: ./application/model/usuarios_model.php */
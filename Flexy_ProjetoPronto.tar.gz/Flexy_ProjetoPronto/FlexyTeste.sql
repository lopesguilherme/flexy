CREATE DATABASE IF NOT EXISTS `flexytest` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `flexytest`;

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nome` varchar(510) NOT NULL,
  `email` varchar(510) NOT NULL,
  `senha` varchar(510) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `produtos` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(510) NOT NULL,
  `descricao` varchar(510) NOT NULL,
   `imagem` longtext,
  `valor` decimal(10,2) NOT NULL DEFAULT '0.00',
   PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

